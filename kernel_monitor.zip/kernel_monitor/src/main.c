/*
 * main.c
 * -----------------------------------------------------------------------
 * Kernel Monitor -- a user-space Linux system/process monitoring tool.
 * Reads /proc for kernel-exposed system and process information and
 * presents it through a simple command-line menu.
 *
 * Team 10, Sec 13 -- Operating Systems and System Programming
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../include/kernel_monitor.h"

static void print_menu(void)
{
    printf("\n=================== KERNEL MONITOR ===================\n");
    printf(" 1. Show system uptime\n");
    printf(" 2. Show CPU info\n");
    printf(" 3. Show memory info\n");
    printf(" 4. Live CPU usage (5 readings, 1s apart)\n");
    printf(" 5. List all processes\n");
    printf(" 6. Show details for a specific PID\n");
    printf(" 7. Terminate a process (SIGTERM)\n");
    printf(" 8. Send a custom signal to a process\n");
    printf(" 9. Show current process's own PID (getpid demo)\n");
    printf(" 0. Exit\n");
    printf("========================================================\n");
    printf("Choice: ");
}

/* Reads one integer from stdin robustly; returns 0 on failure */
static int read_int(long *out)
{
    char buf[64];
    if (!fgets(buf, sizeof(buf), stdin)) return 0;
    char *endptr;
    long val = strtol(buf, &endptr, 10);
    if (endptr == buf) return 0;
    *out = val;
    return 1;
}

int main(void)
{
    long choice;

    printf("Kernel Monitor started. PID of this process: %d\n", getpid());

    while (1) {
        print_menu();
        if (!read_int(&choice)) {
            printf("Invalid input, please enter a number.\n");
            continue;
        }

        switch (choice) {
            case 1:
                show_system_uptime();
                break;
            case 2:
                show_cpu_info();
                break;
            case 3:
                show_memory_info();
                break;
            case 4:
                show_cpu_usage_live(5, 1);
                break;
            case 5:
                list_all_processes();
                break;
            case 6: {
                long pid;
                printf("Enter PID: ");
                if (read_int(&pid)) show_process_details((pid_t)pid);
                else printf("Invalid PID.\n");
                break;
            }
            case 7: {
                long pid;
                printf("Enter PID to terminate: ");
                if (read_int(&pid)) terminate_process((pid_t)pid);
                else printf("Invalid PID.\n");
                break;
            }
            case 8: {
                long pid, sig;
                printf("Enter PID: ");
                if (!read_int(&pid)) { printf("Invalid PID.\n"); break; }
                printf("Enter signal number (e.g. 9=SIGKILL, 15=SIGTERM, 19=SIGSTOP): ");
                if (!read_int(&sig)) { printf("Invalid signal.\n"); break; }
                send_custom_signal((pid_t)pid, (int)sig);
                break;
            }
            case 9:
                printf("This process's PID (via getpid()): %d\n", getpid());
                break;
            case 0:
                printf("Exiting Kernel Monitor.\n");
                return EXIT_SUCCESS;
            default:
                printf("Unknown choice, try again.\n");
        }
    }
}
