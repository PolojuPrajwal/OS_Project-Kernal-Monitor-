/*
 * process_control.c
 * -----------------------------------------------------------------------
 * Basic process-control features on top of kill(2): graceful termination
 * (SIGTERM) and sending an arbitrary signal number.
 * -----------------------------------------------------------------------
 */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include "../include/kernel_monitor.h"

void terminate_process(pid_t pid)
{
    if (kill(pid, SIGTERM) == 0) {
        printf("SIGTERM sent to PID %d.\n", pid);
    } else {
        printf("Failed to signal PID %d: %s\n", pid, strerror(errno));
        if (errno == EPERM)
            printf("(Hint: you may need elevated privileges for this PID.)\n");
    }
}

void send_custom_signal(pid_t pid, int signum)
{
    if (kill(pid, signum) == 0) {
        printf("Signal %d sent to PID %d.\n", signum, pid);
    } else {
        printf("Failed to signal PID %d: %s\n", pid, strerror(errno));
    }
}
