#ifndef KERNEL_MONITOR_H
#define KERNEL_MONITOR_H

#include <sys/types.h>

/* ---------- system_info.c ---------- */
void show_system_uptime(void);
void show_cpu_info(void);
void show_memory_info(void);
void show_cpu_usage_live(int seconds, int interval);

/* ---------- process_info.c ---------- */
void list_all_processes(void);
void show_process_details(pid_t pid);

/* ---------- process_control.c ---------- */
void terminate_process(pid_t pid);
void send_custom_signal(pid_t pid, int signum);

#endif /* KERNEL_MONITOR_H */
