# Kernel Monitor

A user-space Linux system & process monitoring tool written in C, built for
the "Operating Systems and System Programming" course project (Team 10,
Sec 13). It reads kernel-exposed information from the `/proc` filesystem
and presents it through a simple command-line menu.

## Features

| # | Feature                          | Kernel interface used                          |
|---|-----------------------------------|--------------------------------------------------|
| 1 | System uptime                     | `/proc/uptime`                                   |
| 2 | CPU model & core count            | `/proc/cpuinfo`                                  |
| 3 | Memory usage (total/used/free/…)  | `/proc/meminfo`                                  |
| 4 | Live CPU usage % (delta sampling) | `/proc/stat`                                     |
| 5 | List all running processes        | `opendir()`/`readdir()` on `/proc`, `/proc/[pid]/status` |
| 6 | Per-process detail view           | `/proc/[pid]/status`, `/proc/[pid]/stat`, `/proc/[pid]/cmdline` |
| 7 | Terminate a process                | `kill(pid, SIGTERM)`                             |
| 8 | Send an arbitrary signal          | `kill(pid, signum)`                              |
| 9 | Show this process's own PID       | `getpid()`                                       |

## Project layout

```
kernel_monitor/
├── include/
│   └── kernel_monitor.h    # shared declarations
├── src/
│   ├── main.c               # menu-driven CLI
│   ├── system_info.c        # uptime / cpuinfo / meminfo / live CPU usage
│   ├── process_info.c       # process listing + per-PID detail
│   └── process_control.c    # kill()-based signal sending
├── Makefile
└── README.md
```

## Build

Requires `gcc` and a POSIX-compliant Linux environment (relies on `/proc`,
so it will not run on macOS/Windows without WSL).

```bash
make          # builds ./kernel_monitor
make run      # builds and runs it
make clean    # removes build artifacts
```

## Usage

```
$ ./kernel_monitor
Kernel Monitor started. PID of this process: 12345

=================== KERNEL MONITOR ===================
 1. Show system uptime
 2. Show CPU info
 3. Show memory info
 4. Live CPU usage (5 readings, 1s apart)
 5. List all processes
 6. Show details for a specific PID
 7. Terminate a process (SIGTERM)
 8. Send a custom signal to a process
 9. Show current process's own PID (getpid demo)
 0. Exit
========================================================
Choice:
```

Pick a number and follow the prompts. Options 6-8 ask for a PID (find one
from option 5's process list first).

## How it maps to the abstract's objectives

- **Monitor current system state** → uptime + CPU + memory screens.
- **Display running processes and PIDs** → option 5 walks every numeric
  entry under `/proc` with `opendir()`/`readdir()`.
- **Monitor CPU and memory utilization** → `/proc/stat` delta sampling for
  CPU%, `/proc/meminfo` parsing for memory.
- **Basic process monitoring and control** → option 6 (inspect) and
  options 7-8 (`kill()`-based termination/signaling).
- **Understand kernel → user-space exposure** → every reading in this tool
  goes through `open()/read()/close()` (via `fopen`/`fscanf`/`fclose`) on
  files the kernel publishes live under `/proc`, exactly as listed in the
  abstract's "Technologies to be used" section.

## Notes / possible extensions

- Signaling processes you don't own will fail with `EPERM` unless you run
  as root — this is expected sandboxing behavior, not a bug.
- The live CPU usage view samples `/proc/stat` twice (1s apart, 5 times)
  since the kernel only exposes cumulative jiffie counters, not an
  instantaneous percentage — the same technique `top`/`htop` use internally.
- Natural next steps if you want to extend it for a higher grade: add a
  `ncurses`-based live-refreshing dashboard instead of the static menu,
  sort process list by CPU/memory, or log snapshots to a file over time.
