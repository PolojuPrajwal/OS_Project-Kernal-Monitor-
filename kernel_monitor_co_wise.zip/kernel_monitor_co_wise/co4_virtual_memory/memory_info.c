#define _POSIX_C_SOURCE 200809L
/*
 * memory_info.c   (CO4 -- Virtual memory)
 * -----------------------------------------------------------------------
 * Reads system-wide memory statistics exposed by the kernel's memory
 * manager through /proc/meminfo (total, free, available, buffers, page
 * cache).
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include "../include/kernel_monitor.h"

void show_memory_info(void)
{
    FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) {
        perror("fopen(/proc/meminfo)");
        return;
    }

    char key[64];
    long value;
    char unit[16];

    long mem_total = 0, mem_free = 0, mem_available = 0, buffers = 0, cached = 0;

    while (fscanf(fp, "%63s %ld %15s", key, &value, unit) == 3) {
        if (strcmp(key, "MemTotal:") == 0)      mem_total = value;
        else if (strcmp(key, "MemFree:") == 0)  mem_free = value;
        else if (strcmp(key, "MemAvailable:") == 0) mem_available = value;
        else if (strcmp(key, "Buffers:") == 0)  buffers = value;
        else if (strcmp(key, "Cached:") == 0)   cached = value;
    }
    fclose(fp);

    long used = mem_total - mem_free - buffers - cached;
    double used_pct = mem_total ? (100.0 * used / mem_total) : 0.0;

    printf("\n--- Memory Info ---\n");
    printf("Total     : %8ld MB\n", mem_total / 1024);
    printf("Used      : %8ld MB (%.1f%%)\n", used / 1024, used_pct);
    printf("Free      : %8ld MB\n", mem_free / 1024);
    printf("Available : %8ld MB\n", mem_available / 1024);
    printf("Buffers   : %8ld MB\n", buffers / 1024);
    printf("Cached    : %8ld MB\n", cached / 1024);
}
