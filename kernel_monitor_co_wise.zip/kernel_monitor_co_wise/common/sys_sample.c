#define _POSIX_C_SOURCE 200809L
/*
 * sys_sample.c
 * -----------------------------------------------------------------------
 * Small shared helper used by the IPC (CO3) and concurrency (CO6) demos:
 * grabs a quick snapshot of load average and available memory from /proc.
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include "../include/kernel_monitor.h"

int read_system_sample(double *load1, long *mem_available_kb)
{
    *load1 = 0.0;
    *mem_available_kb = 0;

    FILE *fp = fopen("/proc/loadavg", "r");
    if (!fp) return -1;
    if (fscanf(fp, "%lf", load1) != 1) {
        fclose(fp);
        return -1;
    }
    fclose(fp);

    fp = fopen("/proc/meminfo", "r");
    if (!fp) return -1;

    char key[64];
    long value;
    char unit[16];
    while (fscanf(fp, "%63s %ld %15s", key, &value, unit) == 3) {
        if (strcmp(key, "MemAvailable:") == 0) {
            *mem_available_kb = value;
            break;
        }
    }
    fclose(fp);
    return 0;
}
