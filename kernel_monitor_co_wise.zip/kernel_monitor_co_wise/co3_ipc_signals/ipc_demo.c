#define _POSIX_C_SOURCE 200809L
/*
 * ipc_demo.c   (CO3 -- Inter-process communication)
 * -----------------------------------------------------------------------
 * Small multi-process demos of the IPC mechanisms. In each one a child
 * process takes a system sample (load average + available memory from
 * /proc) and sends it to the parent:
 *
 *   demo_pipe()          anonymous pipe        pipe()
 *   demo_fifo()          named pipe            mkfifo()
 *   demo_unix_socket()   Unix domain socket    socket/bind/listen/accept/connect
 *   demo_shared_memory() POSIX shared memory   shm_open/ftruncate/mmap
 *   demo_signal_handler() signals              sigaction/sigsuspend/kill
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/mman.h>
#include "../include/kernel_monitor.h"

/* Builds the text message the child sends to the parent */
static void format_sample(char *buf, size_t len)
{
    double load1;
    long mem_kb;
    if (read_system_sample(&load1, &mem_kb) != 0)
        snprintf(buf, len, "PID %d: sample unavailable", getpid());
    else
        snprintf(buf, len, "PID %d reports: load1=%.2f, MemAvailable=%ld MB",
                 getpid(), load1, mem_kb / 1024);
}

static void reap(pid_t pid)
{
    int status;
    while (waitpid(pid, &status, 0) == -1 && errno == EINTR)
        ;
}

static void sleep_ms(long ms)
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000000L };
    nanosleep(&ts, NULL);
}

/* ------------------------------------------------------------------ */
/* 1. Anonymous pipe: child -> parent                                   */
/* ------------------------------------------------------------------ */
void demo_pipe(void)
{
    int fd[2];
    if (pipe(fd) == -1) {
        perror("pipe");
        return;
    }

    printf("\n--- Anonymous pipe demo ---\n");
    fflush(stdout);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        close(fd[0]);
        close(fd[1]);
        return;
    }

    if (pid == 0) {
        close(fd[0]);                       /* child only writes */
        char msg[160];
        format_sample(msg, sizeof(msg));
        if (write(fd[1], msg, strlen(msg)) < 0) _exit(1);
        close(fd[1]);
        _exit(0);
    }

    close(fd[1]);                           /* parent only reads */
    char buf[200];
    ssize_t n = read(fd[0], buf, sizeof(buf) - 1);
    if (n < 0) {
        perror("read");
    } else {
        buf[n] = '\0';
        printf("[parent] received through pipe: %s\n", buf);
    }
    close(fd[0]);
    reap(pid);
}

/* ------------------------------------------------------------------ */
/* 2. Named pipe (FIFO): child -> parent                                */
/* ------------------------------------------------------------------ */
void demo_fifo(void)
{
    char path[64];
    snprintf(path, sizeof(path), "/tmp/kernel_monitor_fifo_%d", getpid());

    if (mkfifo(path, 0600) == -1) {
        perror("mkfifo");
        return;
    }

    printf("\n--- Named pipe (FIFO) demo: %s ---\n", path);
    fflush(stdout);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        unlink(path);
        return;
    }

    if (pid == 0) {
        int fd = open(path, O_WRONLY);      /* blocks until a reader opens */
        if (fd < 0) _exit(1);
        char msg[160];
        format_sample(msg, sizeof(msg));
        if (write(fd, msg, strlen(msg)) < 0) {
            close(fd);
            _exit(1);
        }
        close(fd);
        _exit(0);
    }

    int fd = open(path, O_RDONLY);          /* blocks until the writer opens */
    if (fd < 0) {
        perror("open(fifo)");
    } else {
        char buf[200];
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        if (n < 0) {
            perror("read");
        } else {
            buf[n] = '\0';
            printf("[parent] received through FIFO: %s\n", buf);
        }
        close(fd);
    }
    reap(pid);
    unlink(path);                           /* remove the FIFO node */
}

/* ------------------------------------------------------------------ */
/* 3. Unix domain socket: child (client) <-> parent (server)            */
/* ------------------------------------------------------------------ */
void demo_unix_socket(void)
{
    char path[64];
    snprintf(path, sizeof(path), "/tmp/kernel_monitor_sock_%d", getpid());

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    snprintf(addr.sun_path, sizeof(addr.sun_path), "%s", path);

    int srv = socket(AF_UNIX, SOCK_STREAM, 0);
    if (srv < 0) {
        perror("socket");
        return;
    }
    unlink(path);
    if (bind(srv, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        perror("bind");
        close(srv);
        return;
    }
    if (listen(srv, 1) == -1) {
        perror("listen");
        close(srv);
        unlink(path);
        return;
    }

    printf("\n--- Unix domain socket demo: %s ---\n", path);
    fflush(stdout);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        close(srv);
        unlink(path);
        return;
    }

    if (pid == 0) {
        /* ---- child = client ---- */
        close(srv);
        int c = socket(AF_UNIX, SOCK_STREAM, 0);
        if (c < 0 || connect(c, (struct sockaddr *)&addr, sizeof(addr)) == -1)
            _exit(1);

        char msg[160];
        format_sample(msg, sizeof(msg));
        if (write(c, msg, strlen(msg)) < 0) _exit(1);

        char reply[64];
        ssize_t n = read(c, reply, sizeof(reply) - 1);
        if (n > 0) {
            reply[n] = '\0';
            printf("[client %d] server replied: %s\n", getpid(), reply);
            fflush(stdout);
        }
        close(c);
        _exit(0);
    }

    /* ---- parent = server ---- */
    int conn = accept(srv, NULL, NULL);
    if (conn < 0) {
        perror("accept");
    } else {
        char buf[200];
        ssize_t n = read(conn, buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = '\0';
            printf("[server] received over socket: %s\n", buf);
            if (write(conn, "ACK", 3) < 0) perror("write");
        }
        close(conn);
    }
    reap(pid);
    close(srv);
    unlink(path);
}

/* ------------------------------------------------------------------ */
/* 4. POSIX shared memory: child writes, parent reads                   */
/* ------------------------------------------------------------------ */
typedef struct {
    pid_t writer_pid;
    double load1;
    long mem_available_kb;
} shared_sample_t;

void demo_shared_memory(void)
{
    char name[48];
    snprintf(name, sizeof(name), "/kernel_monitor_shm_%d", getpid());

    int fd = shm_open(name, O_CREAT | O_RDWR, 0600);
    if (fd < 0) {
        perror("shm_open");
        return;
    }
    if (ftruncate(fd, sizeof(shared_sample_t)) == -1) {
        perror("ftruncate");
        close(fd);
        shm_unlink(name);
        return;
    }

    shared_sample_t *shm = mmap(NULL, sizeof(*shm), PROT_READ | PROT_WRITE,
                                MAP_SHARED, fd, 0);
    if (shm == MAP_FAILED) {
        perror("mmap");
        close(fd);
        shm_unlink(name);
        return;
    }
    memset(shm, 0, sizeof(*shm));

    printf("\n--- Shared memory demo: %s ---\n", name);
    fflush(stdout);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
    } else if (pid == 0) {
        /* child writes directly into the shared mapping */
        shm->writer_pid = getpid();
        read_system_sample(&shm->load1, &shm->mem_available_kb);
        munmap(shm, sizeof(*shm));
        close(fd);
        _exit(0);
    } else {
        /* parent waits (simple synchronisation via waitpid) then reads */
        reap(pid);
        printf("[parent] read from shared memory: writer PID=%d, load1=%.2f, "
               "MemAvailable=%ld MB\n",
               shm->writer_pid, shm->load1, shm->mem_available_kb / 1024);
    }

    munmap(shm, sizeof(*shm));
    close(fd);
    shm_unlink(name);
}

/* ------------------------------------------------------------------ */
/* 5. Signals: custom handler for SIGUSR1                               */
/* ------------------------------------------------------------------ */
static volatile sig_atomic_t got_signal = 0;
static volatile sig_atomic_t last_signal = 0;

static void usr1_handler(int signum)
{
    /* only async-signal-safe work here: set flags, nothing else */
    last_signal = signum;
    got_signal = 1;
}

void demo_signal_handler(void)
{
    printf("\n--- Signal handler demo (SIGUSR1) ---\n");

    struct sigaction sa, old_sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = usr1_handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, &old_sa) == -1) {
        perror("sigaction");
        return;
    }

    /* Block SIGUSR1 until we are ready to wait, so it can't be missed */
    sigset_t block, old_mask;
    sigemptyset(&block);
    sigaddset(&block, SIGUSR1);
    sigprocmask(SIG_BLOCK, &block, &old_mask);

    got_signal = 0;
    fflush(stdout);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        sigprocmask(SIG_SETMASK, &old_mask, NULL);
        sigaction(SIGUSR1, &old_sa, NULL);
        return;
    }

    if (pid == 0) {
        sleep_ms(200);
        kill(getppid(), SIGUSR1);           /* signal the parent */
        _exit(0);
    }

    printf("[parent %d] waiting for SIGUSR1 from child %d...\n", getpid(), pid);
    fflush(stdout);
    while (!got_signal)
        sigsuspend(&old_mask);              /* atomically unblock + sleep */

    printf("[parent] handler ran: caught signal %d (%s)\n",
           (int)last_signal, strsignal((int)last_signal));

    sigprocmask(SIG_SETMASK, &old_mask, NULL);
    sigaction(SIGUSR1, &old_sa, NULL);
    reap(pid);
}
