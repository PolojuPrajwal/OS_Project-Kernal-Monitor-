# Kernel Monitor — CO-wise code split

Build as one program: `make` then `./kernel_monitor` (Linux only; uses /proc, POSIX shm, pthreads).

| CO  | File | Menu option | What it demonstrates | Key calls |
|-----|------|-------------|----------------------|-----------|
| CO1 | `co1_os_abstraction/main.c` | 9, menu loop | User-space program talking to the kernel through syscalls; `getpid()` | `getpid()` |
| CO1 | `co1_os_abstraction/system_info.c` | 1, 2, 4 | Kernel state exposed to user space via /proc (uptime, CPU, live CPU %) | `/proc/uptime`, `/proc/cpuinfo`, `/proc/stat` |
| CO2 | `co2_process_control/process_runner.c` | 10 | Fork a child, `exec` a typed command, wait, decode exit status / killing signal | `fork`, `execvp`, `waitpid`, `_exit` |
| CO2 | `co2_process_control/process_runner.c` | 11 | 3 children with different exit codes, parent reaps all (no zombies) | `fork`, `wait`, `WEXITSTATUS` |
| CO3 | `co3_ipc_signals/process_control.c` | 7, 8 | Send SIGTERM / any signal to a PID, EPERM handling | `kill` |
| CO3 | `co3_ipc_signals/ipc_demo.c` | 12 | Anonymous pipe, child → parent | `pipe` |
| CO3 | `co3_ipc_signals/ipc_demo.c` | 13 | Named pipe (FIFO) | `mkfifo`, `open` |
| CO3 | `co3_ipc_signals/ipc_demo.c` | 14 | Unix domain socket, client (child) ↔ server (parent) | `socket`, `bind`, `listen`, `accept`, `connect` |
| CO3 | `co3_ipc_signals/ipc_demo.c` | 15 | POSIX shared memory | `shm_open`, `ftruncate`, `mmap` |
| CO3 | `co3_ipc_signals/ipc_demo.c` | 16 | Custom SIGUSR1 handler, race-free wait | `sigaction`, `sigprocmask`, `sigsuspend` |
| CO4 | `co4_virtual_memory/memory_info.c` | 3 | System memory stats from the kernel memory manager | `/proc/meminfo` |
| CO5 | `co5_filesystem/process_info.c` | 5, 6 | Directory walk of /proc, per-PID file parsing | `opendir`, `readdir`, `fopen`, `fgets`, `fread` |
| CO6 | `co6_concurrency/concurrency_demo.c` | 17 | Race condition (no lock) vs mutex-protected counter | `pthread_create/join`, `pthread_mutex_*` |
| CO6 | `co6_concurrency/concurrency_demo.c` | 18 | Bounded-buffer producer–consumer | `pthread_cond_wait/signal` |
| CO6 | `co6_concurrency/concurrency_demo.c` | 19 | Counting semaphore limiting 5 workers to 2 at a time | `sem_init/wait/post` |

Shared pieces: `include/kernel_monitor.h`, `common/sys_sample.c` (reads load average + MemAvailable, used by the CO3 and CO6 demos).

## Notes
- Option 17: lost updates only appear on machines with more than one CPU core. On a single core the unsynchronised run can be correct by luck.
- Option 10 splits the command on spaces only (no quote handling), e.g. `ls -l /tmp` works but `sh -c "exit 3"` does not.
- `process_info.c` also prints `VmRSS`/`VmSize` (touches CO4) and utime/stime user vs system CPU time (touches CO1).
