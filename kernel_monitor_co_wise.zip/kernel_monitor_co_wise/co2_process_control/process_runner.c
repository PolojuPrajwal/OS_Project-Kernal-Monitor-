#define _POSIX_C_SOURCE 200809L
/*
 * process_runner.c   (CO2 -- Unix process-control primitives)
 * -----------------------------------------------------------------------
 * Uses fork(), execvp(), waitpid()/wait() and _exit() to create, control
 * and reap child processes:
 *
 *   run_external_command() : fork a child, exec a user-typed command in it,
 *                            wait for it and report how it ended.
 *   fork_wait_demo()       : fork N children that exit with different
 *                            codes; the parent reaps every one of them
 *                            (so none is left as a zombie).
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "../include/kernel_monitor.h"

#define MAX_ARGS 32

/* Decodes a wait() status word into a human-readable line */
static void report_status(pid_t pid, int status)
{
    if (WIFEXITED(status)) {
        printf("Child %d exited normally with status %d.\n",
               pid, WEXITSTATUS(status));
    } else if (WIFSIGNALED(status)) {
        printf("Child %d was killed by signal %d (%s).\n",
               pid, WTERMSIG(status), strsignal(WTERMSIG(status)));
    } else {
        printf("Child %d ended with raw status 0x%x.\n", pid, status);
    }
}

void run_external_command(const char *cmdline)
{
    char buf[512];
    char *argv[MAX_ARGS + 1];
    int argc = 0;

    strncpy(buf, cmdline, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';

    /* Split the line on whitespace into an argv[] array */
    char *saveptr = NULL;
    char *tok = strtok_r(buf, " \t\r\n", &saveptr);
    while (tok && argc < MAX_ARGS) {
        argv[argc++] = tok;
        tok = strtok_r(NULL, " \t\r\n", &saveptr);
    }
    argv[argc] = NULL;

    if (argc == 0) {
        printf("No command entered.\n");
        return;
    }

    printf("\n--- Running '%s' in a child process ---\n", argv[0]);
    fflush(stdout); /* so buffered output isn't duplicated into the child */

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return;
    }

    if (pid == 0) {
        /* ---- child: replace this process image with the command ---- */
        execvp(argv[0], argv);
        /* only reached if exec failed */
        perror("execvp");
        _exit(127);
    }

    /* ---- parent: wait for the child and report ---- */
    printf("Parent %d created child %d, waiting...\n", getpid(), pid);
    int status;
    pid_t w;
    do {
        w = waitpid(pid, &status, 0);
    } while (w == -1 && errno == EINTR);

    if (w == -1) {
        perror("waitpid");
        return;
    }
    report_status(w, status);
}

void fork_wait_demo(int num_children)
{
    if (num_children < 1) num_children = 1;
    if (num_children > 10) num_children = 10;

    printf("\n--- fork()/wait() demo: parent PID %d creating %d children ---\n",
           getpid(), num_children);
    fflush(stdout);

    int created = 0;
    for (int i = 1; i <= num_children; i++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            break;
        }
        if (pid == 0) {
            /* ---- child i ---- */
            printf("  [child %d] PID=%d PPID=%d, exiting with code %d\n",
                   i, getpid(), getppid(), 10 + i);
            fflush(stdout);
            _exit(10 + i);
        }
        created++;
    }

    /* Reap every child; wait() returns -1/ECHILD when none are left */
    int status;
    pid_t w;
    int reaped = 0;
    while (reaped < created) {
        w = wait(&status);
        if (w == -1) {
            if (errno == EINTR) continue;
            break;
        }
        report_status(w, status);
        reaped++;
    }
    printf("Parent reaped %d of %d children (no zombies left).\n", reaped, created);
}
