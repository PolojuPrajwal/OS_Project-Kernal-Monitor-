#ifndef KERNEL_MONITOR_H
#define KERNEL_MONITOR_H

#include <sys/types.h>

/* ---------- CO1: co1_os_abstraction/system_info.c ---------- */
void show_system_uptime(void);
void show_cpu_info(void);
void show_cpu_usage_live(int seconds, int interval);

/* ---------- CO2: co2_process_control/process_runner.c ---------- */
void run_external_command(const char *cmdline);
void fork_wait_demo(int num_children);

/* ---------- CO3: co3_ipc_signals/process_control.c ---------- */
void terminate_process(pid_t pid);
void send_custom_signal(pid_t pid, int signum);

/* ---------- CO3: co3_ipc_signals/ipc_demo.c ---------- */
void demo_pipe(void);
void demo_fifo(void);
void demo_unix_socket(void);
void demo_shared_memory(void);
void demo_signal_handler(void);

/* ---------- CO4: co4_virtual_memory/memory_info.c ---------- */
void show_memory_info(void);

/* ---------- CO5: co5_filesystem/process_info.c ---------- */
void list_all_processes(void);
void show_process_details(pid_t pid);

/* ---------- CO6: co6_concurrency/concurrency_demo.c ---------- */
void demo_race_condition(void);
void demo_producer_consumer(void);
void demo_semaphore_pool(void);

/* ---------- common/sys_sample.c ---------- */
/* Reads 1-minute load average and MemAvailable (KB). Returns 0 on success. */
int read_system_sample(double *load1, long *mem_available_kb);

#endif /* KERNEL_MONITOR_H */
