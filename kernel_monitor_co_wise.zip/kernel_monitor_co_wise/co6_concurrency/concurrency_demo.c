#define _POSIX_C_SOURCE 200809L
/*
 * concurrency_demo.c   (CO6 -- POSIX threads and synchronisation)
 * -----------------------------------------------------------------------
 *   demo_race_condition()    4 threads bump a shared counter: first with
 *                            no lock (lost updates = race condition), then
 *                            with a mutex (always correct).
 *   demo_producer_consumer() sampler thread produces /proc samples into a
 *                            bounded buffer; consumer thread prints them.
 *                            Uses a mutex + two condition variables.
 *   demo_semaphore_pool()    5 worker threads scan /proc but a counting
 *                            semaphore lets only 2 run at the same time.
 *
 * Deadlock note: every structure here is guarded by exactly one mutex and
 * no thread ever holds two locks at once, so a lock-ordering cycle (the
 * classic deadlock) cannot occur. Condition waits are always inside a
 * `while` loop to survive spurious wakeups.
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <dirent.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include "../include/kernel_monitor.h"

static void sleep_ms(long ms)
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000000L };
    nanosleep(&ts, NULL);
}

/* ================================================================== */
/* Demo A: race condition vs mutex                                      */
/* ================================================================== */
#define RACE_THREADS 4
#define RACE_ITERS   200000

/* volatile stops the compiler from collapsing the loop, so the
 * unsynchronised read-modify-write really happens on every iteration */
static volatile long unsafe_counter = 0;
static long safe_counter = 0;
static pthread_mutex_t counter_lock = PTHREAD_MUTEX_INITIALIZER;

static void *unsafe_worker(void *arg)
{
    (void)arg;
    for (int i = 0; i < RACE_ITERS; i++)
        unsafe_counter++;                   /* load, add, store: NOT atomic */
    return NULL;
}

static void *safe_worker(void *arg)
{
    (void)arg;
    for (int i = 0; i < RACE_ITERS; i++) {
        pthread_mutex_lock(&counter_lock);
        safe_counter++;                     /* critical section */
        pthread_mutex_unlock(&counter_lock);
    }
    return NULL;
}

/* Starts RACE_THREADS threads running fn, then joins them all */
static void run_threads(void *(*fn)(void *))
{
    pthread_t tid[RACE_THREADS];
    int started = 0;

    for (int i = 0; i < RACE_THREADS; i++) {
        int rc = pthread_create(&tid[i], NULL, fn, NULL);
        if (rc != 0) {
            fprintf(stderr, "pthread_create: %s\n", strerror(rc));
            break;
        }
        started++;
    }
    for (int i = 0; i < started; i++)
        pthread_join(tid[i], NULL);
}

void demo_race_condition(void)
{
    long expected = (long)RACE_THREADS * RACE_ITERS;

    printf("\n--- Race condition demo (%d threads x %d increments) ---\n",
           RACE_THREADS, RACE_ITERS);

    unsafe_counter = 0;
    run_threads(unsafe_worker);
    printf("Without mutex: counter = %ld (expected %ld, lost %ld updates)\n",
           unsafe_counter, expected, expected - unsafe_counter);

    safe_counter = 0;
    run_threads(safe_worker);
    printf("With mutex   : counter = %ld (expected %ld, lost %ld updates)\n",
           safe_counter, expected, expected - safe_counter);

    printf("(Lost updates need >1 CPU core to show up; on a single core the\n"
           " unsynchronised run may happen to be correct, but it is still a bug.)\n");
}

/* ================================================================== */
/* Demo B: producer-consumer with mutex + condition variables           */
/* ================================================================== */
#define PC_CAP   4
#define PC_ITEMS 8

typedef struct {
    double load1;
    long   mem_kb;
} sample_t;

typedef struct {
    sample_t        buf[PC_CAP];
    int             head, tail, count;
    int             stop;                   /* set if the consumer failed to start */
    pthread_mutex_t lock;
    pthread_cond_t  not_full;
    pthread_cond_t  not_empty;
} bounded_buf_t;

static void *producer(void *arg)
{
    bounded_buf_t *b = arg;

    for (int i = 0; i < PC_ITEMS; i++) {
        sample_t s;
        if (read_system_sample(&s.load1, &s.mem_kb) != 0) {
            s.load1 = 0.0;
            s.mem_kb = 0;
        }
        sleep_ms(50);                       /* fast producer */

        pthread_mutex_lock(&b->lock);
        while (b->count == PC_CAP && !b->stop) {
            printf("  [producer] buffer full, waiting...\n");
            pthread_cond_wait(&b->not_full, &b->lock);
        }
        if (b->stop) {
            pthread_mutex_unlock(&b->lock);
            return NULL;
        }
        b->buf[b->tail] = s;
        b->tail = (b->tail + 1) % PC_CAP;
        b->count++;
        printf("  [producer] stored sample %d (buffer count=%d)\n", i + 1, b->count);
        pthread_cond_signal(&b->not_empty);
        pthread_mutex_unlock(&b->lock);
    }
    return NULL;
}

static void *consumer(void *arg)
{
    bounded_buf_t *b = arg;

    for (int i = 0; i < PC_ITEMS; i++) {
        pthread_mutex_lock(&b->lock);
        while (b->count == 0)
            pthread_cond_wait(&b->not_empty, &b->lock);
        sample_t s = b->buf[b->head];
        b->head = (b->head + 1) % PC_CAP;
        b->count--;
        pthread_cond_signal(&b->not_full);
        pthread_mutex_unlock(&b->lock);

        printf("  [consumer] got sample %d: load1=%.2f, MemAvailable=%ld MB\n",
               i + 1, s.load1, s.mem_kb / 1024);
        sleep_ms(200);                      /* slow consumer -> buffer fills */
    }
    return NULL;
}

void demo_producer_consumer(void)
{
    bounded_buf_t b;
    memset(&b, 0, sizeof(b));
    pthread_mutex_init(&b.lock, NULL);
    pthread_cond_init(&b.not_full, NULL);
    pthread_cond_init(&b.not_empty, NULL);

    printf("\n--- Producer-consumer demo (buffer size %d, %d samples) ---\n",
           PC_CAP, PC_ITEMS);

    pthread_t prod, cons;
    int rc = pthread_create(&prod, NULL, producer, &b);
    if (rc != 0) {
        fprintf(stderr, "pthread_create: %s\n", strerror(rc));
        goto cleanup;
    }
    rc = pthread_create(&cons, NULL, consumer, &b);
    if (rc != 0) {
        fprintf(stderr, "pthread_create: %s\n", strerror(rc));
        /* producer would block forever once the buffer fills; tell it to stop */
        pthread_mutex_lock(&b.lock);
        b.stop = 1;
        pthread_cond_broadcast(&b.not_full);
        pthread_mutex_unlock(&b.lock);
        pthread_join(prod, NULL);
        goto cleanup;
    }

    pthread_join(prod, NULL);
    pthread_join(cons, NULL);
    printf("Done: all %d samples produced and consumed.\n", PC_ITEMS);

cleanup:
    pthread_mutex_destroy(&b.lock);
    pthread_cond_destroy(&b.not_full);
    pthread_cond_destroy(&b.not_empty);
}

/* ================================================================== */
/* Demo C: counting semaphore limiting concurrency                      */
/* ================================================================== */
#define POOL_WORKERS 5
#define POOL_SLOTS   2

static sem_t pool_sem;
static pthread_mutex_t stat_lock = PTHREAD_MUTEX_INITIALIZER;
static int active_workers = 0;
static int max_active = 0;

static int count_processes(void)
{
    DIR *d = opendir("/proc");
    if (!d) return -1;

    int count = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        const char *s = e->d_name;
        int numeric = (*s != '\0');
        for (; *s; s++)
            if (!isdigit((unsigned char)*s)) { numeric = 0; break; }
        if (numeric) count++;
    }
    closedir(d);
    return count;
}

static void *pool_worker(void *arg)
{
    int id = *(int *)arg;

    while (sem_wait(&pool_sem) == -1 && errno == EINTR)
        ;                                   /* P(): take one of the slots */

    pthread_mutex_lock(&stat_lock);
    active_workers++;
    if (active_workers > max_active) max_active = active_workers;
    pthread_mutex_unlock(&stat_lock);

    printf("  [worker %d] got a slot, scanning /proc...\n", id);
    int n = count_processes();
    sleep_ms(300);                          /* pretend the scan is slow */
    printf("  [worker %d] saw %d processes, releasing slot\n", id, n);

    pthread_mutex_lock(&stat_lock);
    active_workers--;
    pthread_mutex_unlock(&stat_lock);

    sem_post(&pool_sem);                    /* V(): give the slot back */
    return NULL;
}

void demo_semaphore_pool(void)
{
    printf("\n--- Counting semaphore demo (%d workers, %d slots) ---\n",
           POOL_WORKERS, POOL_SLOTS);

    if (sem_init(&pool_sem, 0, POOL_SLOTS) == -1) {
        perror("sem_init");
        return;
    }
    active_workers = 0;
    max_active = 0;

    pthread_t tid[POOL_WORKERS];
    int ids[POOL_WORKERS];
    int started = 0;

    for (int i = 0; i < POOL_WORKERS; i++) {
        ids[i] = i + 1;
        int rc = pthread_create(&tid[i], NULL, pool_worker, &ids[i]);
        if (rc != 0) {
            fprintf(stderr, "pthread_create: %s\n", strerror(rc));
            break;
        }
        started++;
    }
    for (int i = 0; i < started; i++)
        pthread_join(tid[i], NULL);

    printf("Max workers active at once: %d (limit %d)\n", max_active, POOL_SLOTS);
    sem_destroy(&pool_sem);
}
